var CristalRouge = 0;
        var UpClic = 1;
        var PrixUp1= 20;
        var PrixUp2= 100;
        var CpsMineur1= 0;
        var devMode= true;
        const fps= 30;

        if(devMode === true) {
            CristalRouge = 1000000000000000000000;
        }

        function ClicMine() {
            CristalRouge+= UpClic;
            document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + Math.round(CristalRouge);

        }

        function Up1() {
            if(CristalRouge >= PrixUp1) {
                UpClic +=1;
                CristalRouge-= PrixUp1;
                PrixUp1= Math.round(PrixUp1 * 1.1);
                document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + Math.round(CristalRouge);
                document.getElementById('IdPrixUp1Text').innerHTML = PrixUp1;
                document.getElementById('niveau_1').innerHTML= UpClic;
            }
            else{
                alert('Pas assez de cristaux, il faut:'+ PrixUp1)
            }
        }

        function Mineur1() {
            if(CristalRouge >= PrixUp2) {
                CristalRouge-=PrixUp2;
                CpsMineur1 += 1;
                PrixUp2= Math.round(PrixUp2 * 1.4);
                document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + Math.round(CristalRouge);
                if(PrixUp2 >= 10000){
                    if(PrixUp2 >= 1000000){
                        document.getElementById('IdPrixUp2Text').innerHTML = Math.floor(PrixUp2/10**Math.round((Math.log10(PrixUp2)-1)))+'E'+ Math.round((Math.log10(PrixUp2)-1));
                    }
                    else{
                    document.getElementById('IdPrixUp2Text').innerHTML = Math.floor(PrixUp2/1000) + 'K';}
                }
                else{
                    document.getElementById('IdPrixUp2Text').innerHTML = PrixUp2;
                }               
                document.getElementById('niveau_2').innerHTML= CpsMineur1;
            }

        }

        setInterval(function() {
            CristalRouge+=CpsMineur1/fps;
            document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + Math.round(CristalRouge);
        },1000/fps)
