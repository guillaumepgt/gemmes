<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'config_database.php';
    $donnees = json_decode($_POST['donnees'], true);

    $red_crystal = $donnees['red_crystal'];
    $gold_mine_level = $donnees['gold_mine_level'];
    $mineur_level = $donnees['mineur_level'];
    $session = $donnees['id'];
    $sql = "UPDATE mine SET red_crystal = '$red_crystal', gold_mine_level = '$gold_mine_level',
                mineur_level = '$mineur_level' WHERE id='$session'";
    mysqli_query($conn, $sql);
    require 'beginning_date.php';
}

