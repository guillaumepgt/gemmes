<?php

require 'config_database.php';
session_start();
$session = $_SESSION['id'];

$years = date('Y');
$month = date('m');
$day = date('d');
$hours = date('H');
$min = date('i');
$sec = date('s');

$sql = "UPDATE info SET years_beginning='$years', month_beginning='$month', day_beginning='$day',
                hour_beginning='$hours', min_beginning='$min', sec_beginning='$sec' WHERE id='$session'";
mysqli_query($conn, $sql);