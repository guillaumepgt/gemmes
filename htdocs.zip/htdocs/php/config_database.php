<?php

// Paramètres de connexion à la base de données

$host = 'localhost';
$dbname = 'users';
$user = 'root';
$pass = 'J3gDW2jVxmuy';

// Connexion à la base de données

$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) {
    die("Connexion échouée: " . mysqli_connect_error());
}


