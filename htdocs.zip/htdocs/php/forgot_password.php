<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Cristal</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<?php

require 'config_database.php';

require 'verification_forgot_password.php'
?>
<div class="Login_Frame">
    <h1>Mot de passe oublié</h1>
    <form action="" method="POST">
        <p class="souvenir">
            <a href="http://98.66.136.103/">Retour</a>
        </p>
        <div class="case">
            <label>Email</label>
            <input required="" name="email" type="email">
        </div>
        <div class="conec">
            <button type="submit" name="réinitialiser">Réinitialiser</button>
        </div>
    </form>
    <br>
    <span><?php $message = '';
        echo $message; ?></span>
    <br>
    <p class="nocompte">
        Pas de compte,
        <a href="php/register">Inscrit toi!</a>
    </p>
</div>
</body>
</html>
