<?php
require 'config_database.php';
// Vérification de la soumission du formulaire
if(isset($_POST['connexion'])) {
    // Récupération des valeurs du formulaire
    $email = $_POST['email'];
    $password = $_POST['password'];


    // Requête de vérification de l'utilisateur
    $sql = $conn->query("SELECT id,password FROM info WHERE email = '$email'");
    $result = $sql->fetch_all();
    if ($result) {
        foreach ($result as $row) {
            $id = $row[0];
            if (password_verify($password, $row[1])) {
                $_SESSION['id'] = $id;
                header("Location: php/gemme");
                exit();
            } else {
                $message = "Mauvais mot de passe";
            }
        }
    } else {
        $message = "Mauvaise adresse mail"; }
}
