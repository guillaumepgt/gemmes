let lv1 = parseInt(lv1b);
var lv2= parseInt(lv2b);
var date = parseInt(dateb);
var CristalRouge = parseInt(CristalRougeb) + date*lv2;
var UpClic = 1;
var PrixUp1= 20;
for (let i = 0; i < lv1; i++) {
    PrixUp1 = Math.round(PrixUp1 * 1.1);
}
var PrixUp2= 100;
for (let i = 0; i < lv2; i++) {
    PrixUp2 = Math.round(PrixUp2 * 1.4);
}
var NextProdUp1=lv1+1;
var NextProdUP2=lv2+1;
var Prod1= lv1;
var Prod2=lv2;
var CpsMineur1= 0;
var devMode= true;
var ones=true;
var ten= false;
var hundred=false;
const fps= 30;
var monnaie = ['K','M','MM','AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ', 'BA', 'BB', 'BC', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BK', 'BL', 'BM', 'BN', 'BO', 'BP', 'BQ', 'BR', 'BS', 'BT', 'BU', 'BV', 'BW', 'BX', 'BY', 'BZ', 'CA', 'CB', 'CC', 'CD', 'CE', 'CF', 'CG', 'CH', 'CI', 'CJ', 'CK', 'CL', 'CM', 'CN', 'CO', 'CP', 'CQ', 'CR', 'CS', 'CT', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DA', 'DB', 'DC', 'DD', 'DE', 'DF', 'DG', 'DH', 'DI', 'DJ', 'DK', 'DL', 'DM', 'DN', 'DO', 'DP', 'DQ', 'DR', 'DS', 'DT', 'DU', 'DV', 'DW', 'DX', 'DY', 'DZ', 'EA', 'EB', 'EC', 'ED', 'EE', 'EF', 'EG', 'EH', 'EI', 'EJ', 'EK', 'EL', 'EM', 'EN', 'EO', 'EP', 'EQ', 'ER', 'ES', 'ET', 'EU', 'EV', 'EW', 'EX', 'EY', 'EZ', 'FA', 'FB', 'FC', 'FD', 'FE', 'FF', 'FG', 'FH', 'FI', 'FJ', 'FK', 'FL', 'FM', 'FN', 'FO', 'FP', 'FQ', 'FR', 'FS', 'FT', 'FU', 'FV', 'FW', 'FX', 'FY', 'FZ', 'GA', 'GB', 'GC', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GJ', 'GK', 'GL', 'GM', 'GN', 'GO', 'GP', 'GQ', 'GR', 'GS', 'GT', 'GU', 'GV', 'GW', 'GX', 'GY', 'GZ', 'HA', 'HB', 'HC', 'HD', 'HE', 'HF', 'HG', 'HH', 'HI', 'HJ', 'HK', 'HL', 'HM', 'HN', 'HO', 'HP', 'HQ', 'HR', 'HS', 'HT', 'HU', 'HV', 'HW', 'HX', 'HY', 'HZ', 'IA', 'IB', 'IC', 'ID', 'IE', 'IF', 'IG', 'IH', 'II', 'IJ', 'IK', 'IL', 'IM', 'IN', 'IO', 'IP', 'IQ', 'IR', 'IS', 'IT', 'IU', 'IV', 'IW', 'IX', 'IY', 'IZ', 'JA', 'JB', 'JC', 'JD', 'JE', 'JF', 'JG', 'JH', 'JI', 'JJ', 'JK', 'JL', 'JM', 'JN', 'JO', 'JP', 'JQ', 'JR', 'JS', 'JT', 'JU', 'JV', 'JW', 'JX', 'JY', 'JZ', 'KA', 'KB', 'KC', 'KD', 'KE', 'KF', 'KG', 'KH', 'KI', 'KJ', 'KK', 'KL', 'KM', 'KN', 'KO', 'KP', 'KQ', 'KR', 'KS', 'KT', 'KU', 'KV', 'KW', 'KX', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LD', 'LE', 'LF', 'LG', 'LH', 'LI', 'LJ', 'LK', 'LL', 'LM', 'LN', 'LO', 'LP', 'LQ', 'LR', 'LS', 'LT', 'LU', 'LV', 'LW', 'LX', 'LY', 'LZ', 'MA', 'MB', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MI', 'MJ', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NB', 'NC', 'ND', 'NE', 'NF', 'NG', 'NH', 'NI', 'NJ', 'NK', 'NL', 'NM', 'NN', 'NO', 'NP', 'NQ', 'NR', 'NS', 'NT', 'NU', 'NV', 'NW', 'NX', 'NY', 'NZ', 'OA', 'OB', 'OC', 'OD', 'OE', 'OF', 'OG', 'OH', 'OI', 'OJ', 'OK', 'OL', 'OM', 'ON', 'OO', 'OP', 'OQ', 'OR', 'OS', 'OT', 'OU', 'OV', 'OW', 'OX', 'OY', 'OZ', 'PA', 'PB', 'PC', 'PD', 'PE', 'PF', 'PG', 'PH', 'PI', 'PJ', 'PK', 'PL', 'PM', 'PN', 'PO', 'PP', 'PQ', 'PR', 'PS', 'PT', 'PU', 'PV', 'PW', 'PX', 'PY', 'PZ', 'QA', 'QB', 'QC', 'QD', 'QE', 'QF', 'QG', 'QH', 'QI', 'QJ', 'QK', 'QL', 'QM', 'QN', 'QO', 'QP', 'QQ', 'QR', 'QS', 'QT', 'QU', 'QV', 'QW', 'QX', 'QY', 'QZ', 'RA', 'RB', 'RC', 'RD', 'RE', 'RF', 'RG', 'RH', 'RI', 'RJ', 'RK', 'RL', 'RM', 'RN', 'RO', 'RP', 'RQ', 'RR', 'RS', 'RT', 'RU', 'RV', 'RW', 'RX', 'RY', 'RZ', 'SA', 'SB', 'SC', 'SD', 'SE', 'SF', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SP', 'SQ', 'SR', 'SS', 'ST', 'SU', 'SV', 'SW', 'SX', 'SY', 'SZ', 'TA', 'TB', 'TC', 'TD', 'TE', 'TF', 'TG', 'TH', 'TI', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO', 'TP', 'TQ', 'TR', 'TS', 'TT', 'TU', 'TV', 'TW', 'TX', 'TY', 'TZ', 'UA', 'UB', 'UC', 'UD', 'UE', 'UF', 'UG', 'UH', 'UI', 'UJ', 'UK', 'UL', 'UM', 'UN', 'UO', 'UP', 'UQ', 'UR', 'US', 'UT', 'UU', 'UV', 'UW', 'UX', 'UY', 'UZ', 'VA', 'VB', 'VC', 'VD', 'VE', 'VF', 'VG', 'VH', 'VI', 'VJ', 'VK', 'VL', 'VM', 'VN', 'VO', 'VP', 'VQ', 'VR', 'VS', 'VT', 'VU', 'VV', 'VW', 'VX', 'VY', 'VZ', 'WA', 'WB', 'WC', 'WD', 'WE', 'WF', 'WG', 'WH', 'WI', 'WJ', 'WK', 'WL', 'WM', 'WN', 'WO', 'WP', 'WQ', 'WR', 'WS', 'WT', 'WU', 'WV', 'WW', 'WX', 'WY', 'WZ', 'XA', 'XB', 'XC', 'XD', 'XE', 'XF', 'XG', 'XH', 'XI', 'XJ', 'XK', 'XL', 'XM', 'XN', 'XO', 'XP', 'XQ', 'XR', 'XS', 'XT', 'XU', 'XV', 'XW', 'XX', 'XY', 'XZ', 'YA', 'YB', 'YC', 'YD', 'YE', 'YF', 'YG', 'YH', 'YI', 'YJ', 'YK', 'YL', 'YM', 'YN', 'YO', 'YP', 'YQ', 'YR', 'YS', 'YT', 'YU', 'YV', 'YW', 'YX', 'YY', 'YZ', 'ZA', 'ZB', 'ZC', 'ZD', 'ZE', 'ZF', 'ZG', 'ZH', 'ZI', 'ZJ', 'ZK', 'ZL', 'ZM', 'ZN', 'ZO', 'ZP', 'ZQ', 'ZR', 'ZS', 'ZT', 'ZU', 'ZV', 'ZW', 'ZX', 'ZY', 'ZZ']

function test(tests) {
    var longueur,longueurr,tost;
    tests=Math.round(tests);
    longueur = Math.floor(tests.toString().length / 3) -1;
    if (((tests.toString().length)%3)==0){
        longueurr = Math.round((tests.toString().length - 3) );

    }
    else if (((tests.toString().length)%3)==1){
        longueurr = Math.round((tests.toString().length - 1) );
    }
    else {
        longueurr = Math.round((tests.toString().length -2) );
    }
    tost = tests / Math.pow(10, longueurr)
    tost=tost.toFixed(2)
    if (longueur==-1 || longueur==-2){
        return[tost]
    }
    else{
        return [tost+monnaie[longueur]];
    }
}

document.getElementById('niveau_1').innerHTML = test(lv1);
document.getElementById('niveau_2').innerHTML = test(lv2);
document.getElementById('NextProdUP2').innerHTML = test(NextProdUP2);
document.getElementById('NextProdUP1').innerHTML = test(NextProdUp1);
document.getElementById('Prod1').innerHTML = test(Prod1);
document.getElementById('Prod2').innerHTML = test(Prod2);
document.getElementById('PrixUp1').innerHTML = test(PrixUp1);
document.getElementById('PrixUp2').innerHTML = test(PrixUp2);
document.getElementById('upgradess').innerHTML="Upgrade x1";
document.getElementById('CristalR-text').innerHTML = test(CristalRouge);



function ClicMine() {
    CristalRouge+= Prod1;
    document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + test(CristalRouge);
    envoyerRequete();
}

function envoyerRequete() {
    // Création de l'objet XMLHttpRequest
    var xhr = new XMLHttpRequest();

    // Définition de la fonction de rappel lorsque la requête est terminée
    var donnees = {
        red_crystal: CristalRouge,
        gold_mine_level: lv1,
        mineur_level: lv2,
        id: id
    };
    var params = 'donnees=' + JSON.stringify(donnees);

    // Envoi de la requête en mode POST
    xhr.open('POST', 'add_values.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(params);
}
function Up1() {
    if((CristalRouge >= PrixUp1)&& ones===true){
        Prod1+=1;
        NextProdUp1= Prod1+1;
        lv1 += 1;
        CristalRouge-= PrixUp1;
        PrixUp1= Math.round(PrixUp1 * 1.1);

    }
    else if((CristalRouge >= PrixUp1*1.1**10) && (ten===true)) {
        Prod1+=10;
        NextProdUp1= Prod1+1;
        lv1 += 10;
        CristalRouge-= PrixUp1*1.1**10;
        PrixUp1= PrixUp1 * 1.1**10;

    }
    else if((CristalRouge >= PrixUp1*(1.1**10))&& hundred===true){
        Prod1+=100;
        NextProdUp1= Prod1+1;
        lv1 += 100;
        CristalRouge-= PrixUp1*(1.1**100);
        PrixUp1= Math.round(PrixUp1 * (1.1**100));

    }
    document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + test(CristalRouge);
    document.getElementById('PrixUp1').innerHTML = test(PrixUp1);
    document.getElementById('niveau_1').innerHTML= test(lv1);
    document.getElementById('Prod1').innerHTML= test(Prod1);
    document.getElementById('NextProdUP1').innerHTML= test(NextProdUp1);
    envoyerRequete();
}



function Mineur1() {
    if((CristalRouge >= PrixUp2)&& ones===true ){
        CristalRouge-=PrixUp2;
        Prod2 +=1;
        lv2 +=1;
        NextProdUP2= Prod2+1;
        PrixUp2= Math.round(PrixUp2 * 1.4);
    }
    else if((CristalRouge >= PrixUp2*(1.4**10))&& ten===true ){
        CristalRouge-=PrixUp2*(1.4**10);
        Prod2 +=10;
        lv2 +=10;
        NextProdUP2= Prod2+1;
        PrixUp2= Math.round(PrixUp2 * (1.4**10));

    }
    else if((CristalRouge >= PrixUp2*(1.4**100))&& hundred===true ){
        CristalRouge-=PrixUp2*(1.4**100);
        Prod2 +=100;
        lv2 +=100;
        NextProdUP2= Prod2+1;
        PrixUp2= Math.round(PrixUp2 * (1.4**100));
    }
    document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + test(CristalRouge);
    document.getElementById('PrixUp2').innerHTML= test(PrixUp2);
    document.getElementById('niveau_2').innerHTML= test(lv2);
    document.getElementById('Prod2').innerHTML= test(Prod2);
    document.getElementById('NextProdUP2').innerHTML= test(NextProdUP2);
    envoyerRequete();
}


setInterval(function() {
    CristalRouge+=Prod2/fps;
    document.getElementById('CristalR-text').innerHTML = "Cristaux Rouge:" + test(CristalRouge);
},1000/fps)


function one(){
    ones= true;
    ten= false;
    hundred= false;
    document.getElementById('upgradess').innerHTML="Upgrade x1";
}

function tens(){
    ones= false
    ten= true
    hundred=false
    document.getElementById('upgradess').innerHTML="Upgrade x10";
}

function hundreds(){
    ones=false
    ten=false
    hundred= true
    document.getElementById('upgradess').innerHTML="Upgrade x100";
}