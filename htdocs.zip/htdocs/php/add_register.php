<?php

require 'config_database.php';
$continu = true;

// Vérification de la soumission du formulaire
if(isset($_POST['register'])) {
    // Récupération des valeurs du formulaire
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $hash_password = password_hash($password, PASSWORD_BCRYPT);

    //verifie pas de doublon mail
    $sql = $conn->query("SELECT * FROM info WHERE email = '$email'");
    $result = $sql->fetch_all();
    if ($result) {
        $false_email = 'Adresse mail déjà utilisé';
        $continu = false;

    }

    //verifie pas de doublon pseudo
    $sql = $conn->query("SELECT * FROM info WHERE username = '$username'");
    $result = $sql->fetch_all();
    if ($result) {
        $false_username = 'Pseudo déjà utilisé';
        $continu = false;
    }


    // Requête de l'ajout de l'utilisateur
    if ($continu) {
        $sql = "INSERT INTO info (username, email, password, admin) VALUES ('$username', '$email', '$hash_password', 0)";
        mysqli_query($conn, $sql);

        $sql = $conn->query("SELECT id FROM info WHERE email = '$email'");
        $result = $sql->fetch_all();
        foreach ($result as $row) {
            $id = $row[0];
            $sql = "INSERT INTO mine (id, red_crystal, gold_mine_level, mineur_level) VALUES ('$id', 0, 1, 0);";
            mysqli_query($conn,$sql);
        }
        session_start();
        $_SESSION['id'] = $id;
        header("Location: gemme");
        exit;
    }
}