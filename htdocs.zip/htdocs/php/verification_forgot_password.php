<?php

require 'config_database.php';
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '/../../PHPMailer/src/Exception.php';
require '/../../PHPMailer/src/PHPMailer.php';
require '/../../PHPMailer/src/SMTP.php';

// Vérification de la soumission du formulaire
if(isset($_POST['réinitialiser'])) {
    // Récupération des valeurs du formulaire
    $email = $_POST['email'];


    // Requête de vérification de l'utilisateur
    $sql = "SELECT * FROM info WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    // Vérification de l'existence de l'utilisateur
    if(mysqli_num_rows($result) == 1) {
        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
            //Server settings
            $mail->SMTPDebug = 2;                                 // Enable verbose debug output
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'mail.brightcrave.fr';                  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'gemmes@brightcrave.fr';             // SMTP username
            $mail->Password = 'nH2@*sqPEJd1jm_';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable SSL encryption, TLS also accepted with port 465
            $mail->Port = 465;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('contact@example.com', 'Mailer');          //This is the email your form sends From
            $mail->addAddress('guillaume.prigent44@gmail.com', 'Joe User'); // Add a recipient address
            //$mail->addAddress('contact@example.com');               // Name is optional
            //$mail->addReplyTo('info@example.com', 'Information');
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');

            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

            //Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Subject line goes here';
            $mail->Body    = 'Body text goes here';
            //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            $message = 'Message has been sent';
        } catch (Exception $e) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
        }
    } else {
        $message = "Email jamais utiliser";
        exit;
    }

    // Fermeture de la connexion
    mysqli_close($conn);
}
