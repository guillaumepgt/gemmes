<?php
$verif=false;
// Vérifier si l'utilisateur est connecté
if(!session_id()) {
    session_start();
    session_regenerate_id();
    $verif=true;

}