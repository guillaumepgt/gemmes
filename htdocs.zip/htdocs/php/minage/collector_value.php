<?php

require '/home/bitnami/htdocs/php/config_database.php';

//recherche des données du jeu dans mine
$sql = $conn->query("SELECT red_crystal, gold_mine_level, mineur_level FROM mine WHERE id='$session'");
$result = $sql->fetch_all();
if ($result) {
    foreach ($result as $row) {
        $red_crystal = $row[0];
        $gold_mine_level = $row[1];
        $mineur_level = $row[2];
    }
}