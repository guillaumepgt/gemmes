<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cristal</title>
    <link rel="stylesheet" type="text/css" href="../css/styless.css">
</head>
    <body>
    <?php
    session_start();
    $session = $_SESSION['id'];
    if(!isset($_SESSION['id']))
        header('Location: ../index');
    require 'collector_value.php';
    ?>
        <nav id="navi" class="navbar">
            <a href="gemme" class="logo">CRISTAL</a>
            <div class="navlinks">
                <ul>
                    <li><a href="gemme">Accueil</a></li>
                    <li><a href="#">Boutique</a></li>
                    <li><a href="#">Inventaire</a></li>
                    <li><a href="#">Stats</a></li>
                    <li><a href="#">Autres</a></li>
                    <li><a href="#">Paramètres</a></li>
                    <li><a href="logout">Déconnexion</a></li>
                </ul>
            </div>
            <img src="../img/menubout.png" class="menubouton">
        </nav>
        <div class="upgrade">
            <button id="test" onclick="ClicMine()"></button>
            <div class="droite">
                <div class="bgupc">
                    <button type=button id="bgup" class="bgup" onclick="Up1()"></button>
                </div>
                <div class="centerr"><img class="bgl" src="../img/level.png">
                    <p id="niveau_1"></p>
                </div>
                <div class="produc">
                    <img class="prod" src="../img/production.png">
                    <p id="Prod1"></p>
                </div>
                <div class="bestprice">
                    <img class="bgu" src="../img/meilleur-prix.png">
                    <div class="centerl">
                        <p id="PrixUp1"></p>
                        <img class="bgu" src="../img/logo.png">
                    </div>
                </div>
                <div class="prodnext">
                    <img class="pronext" src="../img/productionnext.png" >
                    <p id="NextProdUP1"></p>
                </div>
                <div class="niveauame">
                    <button class="one" onclick="one()"></button>
                    <button class="ten" onclick="tens()"></button>
                    <button class="hundred" onclick="hundreds()"></button>
                </div>
            </div>
        </div>
        <br>
        <div class="upgrade">
            <button id="test2"></button>
            <div class="droite">
                <div class="bgupc"><button class="bgup" onclick="Mineur1()"></button> </div>
                <div class="centerr"><img class="bgl" src="../img/level.png">
                    <p id="niveau_2"></p>
                </div>
                <div class="produc">
                    <img class="prod" src="../img/meilleur-prix.png">
                    <p id="Prod2"></p>
                </div>
                <div class="bestprice">
                    <img class="bgu" src="../img/meilleur-prix.png">
                    <div class="centerl">
                        <p id="PrixUp2"></p>
                        <img class="bgu" src="../img/logo.png">
                    </div>
                </div>
                <div class="prodnext">
                    <img class="pronext" src="../img/productionnext.png" >
                    <p id="NextProdUP2"></p>
                </div>
                <div class="niveauame">
                    <button class="one" onclick="one()"></button>
                    <button class="ten" onclick="tens()"></button>
                    <button class="hundred" onclick="hundreds()"></button>
                </div>
            </div>
        </div>
        <div class="money">
            <div class="cristaltext"><p id="CristalR-text"></p><p id="upgradess"></p></div>
        </div>
    </body>
<script>
    var CristalRougeb = '<?= $red_crystal ?>';
    var lv1b = '<?= $gold_mine_level ?>';
    var lv2b = '<?= $mineur_level ?>';
    var id = '<?= $session ?>';
    var dateb = '<?= $date ?>'
</script>
<script src="script.js"></script>
    <script>
        envoyerRequete();
        const menuHamburger = document.querySelector(".menubouton")
        const navLinks = document.querySelector(".navlinks")

        menuHamburger.addEventListener('click',()=>{
        navLinks.classList.toggle('mobile-menu')
        })
</script>
</html>
