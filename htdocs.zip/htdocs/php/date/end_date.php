<?php

require '/home/bitnami/htdocs/php/config_database.php';

$sql = $conn->query("SELECT years_beginning, month_beginning, day_beginning, hour_beginning, min_beginning, 
       sec_beginning FROM info WHERE id = '$session'");
$result = $sql->fetch_all();
if ($result) {
    foreach ($result as $row) {
        $years_end = $result[0];
        $month_end = $result[1];
        $day_end = $result[2];
        $hours_end = $result[3];
        $min_end = $result[4];
        $sec_end = $result[5];
        $years = date('Y');
        $month = date('m');
        $day = date('d');
        $hours = date('H');
        $min = date('i');
        $sec = date('s');
        $date = ($years - $years_end) * 31540000 + ($month - $month_end) * 2628000 + ($day - $day_end) * 86400 + ($hour - $hours_end) * 3600
            + ($min - $min_end) * 60 + ($sec - $sec_end);
    }
}