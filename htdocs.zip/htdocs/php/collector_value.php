<?php

require 'config_database.php';
//recherche des données du jeu dans mine
$sql = $conn->query("SELECT red_crystal, gold_mine_level, mineur_level FROM mine WHERE id='$session'");
$result = $sql->fetch_all();
if ($result) {
    foreach ($result as $row) {
        $red_crystal = $row[0];
        $gold_mine_level = $row[1];
        $mineur_level = $row[2];
    }
}

$sql = $conn->query("SELECT years_beginning, month_beginning, day_beginning, hour_beginning, min_beginning, 
       sec_beginning FROM info WHERE id = '$session'");
$result = $sql->fetch_all();
if ($result) {
    foreach ($result as $row) {
        $years_end = $row[0];
        $month_end = $row[1];
        $day_end = $row[2];
        $hours_end = $row[3];
        $min_end = $row[4];
        $sec_end = $row[5];
        $years = date('Y');
        $month = date('m');
        $day = date('d');
        $hours = date('H');
        $min = date('i');
        $sec = date('s');
        $date = ($years - $years_end) * 31540000 + ($month - $month_end) * 2628000 + ($day - $day_end) * 86400 +
            ($hours - $hours_end) * 3600 + ($min - $min_end) * 60 + ($sec - $sec_end);
    }
}