<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Cristal</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<?php

require 'config_database.php';

require 'add_register.php'
?>
<div class="Login_Frame">
    <h1>Inscription</h1>
    <form action="" method="POST">
        <div class="case">
            <label>Pseudo</label>
            <input required="" name="username" type="text">
        </div>
        <br>
        <span><?php echo $false_username; ?></span>
        <br>
        <div class="case">
            <label>Email</label>
            <input required="" name="email" type="email">
        </div>
        <br>
        <span><?php echo $false_email; ?></span>
        <br>
        <div class="case">
            <label>Mot de passe</label>
            <input required="" name="password" type="password">
        </div>
        <div class="conec">
            <button type="submit" name="register">Inscription</button>
        </div>
    </form>
    <br>
    <span><?php echo $message; ?></span>
    <br>
    <p class="nocompte">
        Déjà un compte,
        <a href="../index">Connecte toi!</a>
    </p>
</div>
</body>
</html>
